class Test:
    def __init__(self):
        print("class has been initialized and object is created")


    def test1(self):
        print("this function is for testing purpose")



        